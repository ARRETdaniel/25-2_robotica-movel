resent changes: 
1. links now without <>
2. Use citeonline when referencing directly to an author.
3. attetion: 4.2.2 Referências a organization https://mirrors.ibiblio.org/CTAN/macros/latex/contrib/abntex2/doc/abntex2cite-alf.pdf
4. 